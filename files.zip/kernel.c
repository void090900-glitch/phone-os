// Tiny phone OS, step 2: draw a phone-style screen.
#include <stdint.h>

// ---------------------------------------------------------------
// Serial port (UART) - same as step 1
// ---------------------------------------------------------------
#define UART_BASE  0x09000000UL
#define UART_DR    (*(volatile uint32_t *)(UART_BASE + 0x00))
#define UART_FR    (*(volatile uint32_t *)(UART_BASE + 0x18))
#define UART_TXFF  (1 << 5)
#define UART_RXFE  (1 << 4)

static void uart_putc(char c) {
    while (UART_FR & UART_TXFF) { }
    UART_DR = c;
}

static void uart_puts(const char *s) {
    while (*s) {
        if (*s == '\n') uart_putc('\r');
        uart_putc(*s++);
    }
}

static char uart_getc(void) {
    while (UART_FR & UART_RXFE) { }
    return (char)UART_DR;
}

// ---------------------------------------------------------------
// Talking to QEMU's "fw_cfg" device, which is how we tell the
// virtual screen (ramfb) where our pixels live in memory.
// ---------------------------------------------------------------
#define FW_BASE  0x09020000UL
#define FW_DATA  (*(volatile uint8_t  *)(FW_BASE + 0x00))
#define FW_SEL   (*(volatile uint16_t *)(FW_BASE + 0x08))
#define FW_DMA   (*(volatile uint64_t *)(FW_BASE + 0x10))

#define bswap16 __builtin_bswap16
#define bswap32 __builtin_bswap32
#define bswap64 __builtin_bswap64

static void fw_read(void *dst, uint32_t n) {
    uint8_t *p = dst;
    while (n--) *p++ = FW_DATA;
}

static int streq(const char *a, const char *b) {
    while (*a && *a == *b) { a++; b++; }
    return *a == *b;
}

// Look up a named file in fw_cfg. Returns its selector, or -1.
static int fw_find(const char *name) {
    uint32_t count;
    FW_SEL = bswap16(0x0019);              // file directory
    fw_read(&count, 4);
    count = bswap32(count);

    for (uint32_t i = 0; i < count; i++) {
        struct { uint32_t size; uint16_t select; uint16_t reserved; char name[56]; } e;
        fw_read(&e, 64);
        if (streq(e.name, name)) return bswap16(e.select);
    }
    return -1;
}

struct fw_dma {
    uint32_t control;
    uint32_t length;
    uint64_t address;
} __attribute__((packed, aligned(8)));

static void fw_write_file(int sel, void *buf, uint32_t len) {
    static volatile struct fw_dma d;
    d.control = bswap32(((uint32_t)sel << 16) | 0x08 /*SELECT*/ | 0x10 /*WRITE*/);
    d.length  = bswap32(len);
    d.address = bswap64((uint64_t)buf);
    FW_DMA = bswap64((uint64_t)&d);
    while (bswap32(d.control) & 0xFFFFFFFEu) { }   // wait until done
}

// ---------------------------------------------------------------
// The screen
// ---------------------------------------------------------------
#define W        360
#define H        640
#define FB_ADDR  0x41000000UL          // where our pixels live in RAM

static uint32_t *const fb = (uint32_t *)FB_ADDR;

struct ramfb_cfg {
    uint64_t addr;
    uint32_t fourcc;
    uint32_t flags;
    uint32_t width;
    uint32_t height;
    uint32_t stride;
} __attribute__((packed, aligned(8)));

static int screen_init(void) {
    int sel = fw_find("etc/ramfb");
    if (sel < 0) return -1;

    static struct ramfb_cfg cfg;
    cfg.addr   = bswap64(FB_ADDR);
    cfg.fourcc = bswap32(0x34325258);  // "XR24" = 0x00RRGGBB pixels
    cfg.flags  = bswap32(0);
    cfg.width  = bswap32(W);
    cfg.height = bswap32(H);
    cfg.stride = bswap32(W * 4);
    fw_write_file(sel, &cfg, sizeof(cfg));
    return 0;
}

// ---------------------------------------------------------------
// Drawing helpers
// ---------------------------------------------------------------
static void rect(int x, int y, int w, int h, uint32_t color) {
    for (int yy = y; yy < y + h; yy++)
        for (int xx = x; xx < x + w; xx++)
            fb[yy * W + xx] = color;
}

// A "rounded" rectangle: two overlapping rectangles cut the corners.
static void rrect(int x, int y, int w, int h, int r, uint32_t color) {
    rect(x + r, y, w - 2 * r, h, color);
    rect(x, y + r, w, h - 2 * r, color);
}

// 5x7 pixel font: digits 0-9 and ':' (index 10)
static const uint8_t font[11][7] = {
    {0x0E,0x11,0x13,0x15,0x19,0x11,0x0E}, // 0
    {0x04,0x0C,0x04,0x04,0x04,0x04,0x0E}, // 1
    {0x0E,0x11,0x01,0x02,0x04,0x08,0x1F}, // 2
    {0x1E,0x01,0x01,0x0E,0x01,0x01,0x1E}, // 3
    {0x02,0x06,0x0A,0x12,0x1F,0x02,0x02}, // 4
    {0x1F,0x10,0x1E,0x01,0x01,0x11,0x0E}, // 5
    {0x06,0x08,0x10,0x1E,0x11,0x11,0x0E}, // 6
    {0x1F,0x01,0x02,0x04,0x08,0x08,0x08}, // 7
    {0x0E,0x11,0x11,0x0E,0x11,0x11,0x0E}, // 8
    {0x0E,0x11,0x11,0x0F,0x01,0x02,0x0C}, // 9
    {0x00,0x04,0x04,0x00,0x04,0x04,0x00}, // :
};

static void draw_text(const char *s, int x, int y, int scale, uint32_t color) {
    for (; *s; s++) {
        int idx = (*s == ':') ? 10 : (*s - '0');
        for (int row = 0; row < 7; row++)
            for (int col = 0; col < 5; col++)
                if (font[idx][row] & (0x10 >> col))
                    rect(x + col * scale, y + row * scale, scale, scale, color);
        x += 6 * scale;
    }
}

// ---------------------------------------------------------------
// The "home screen"
// ---------------------------------------------------------------
static void draw_home_screen(void) {
    // Wallpaper: a blue-purple gradient
    for (int y = 0; y < H; y++) {
        uint32_t c = ((20 + y / 16) << 16) | ((30 + y / 10) << 8) | (80 + y / 8);
        rect(0, y, W, 1, c);
    }

    // Status bar with a small clock
    rect(0, 0, W, 28, 0x0B0F2A);
    draw_text("12:34", 12, 8, 2, 0xFFFFFF);

    // Big clock
    draw_text("12:34", 64, 330, 8, 0xFFFFFF);

    // App icons: 4 columns x 2 rows
    static const uint32_t app_colors[8] = {
        0xE74C3C, 0xF39C12, 0xF1C40F, 0x2ECC71,
        0x1ABC9C, 0x3498DB, 0x9B59B6, 0xEC407A,
    };
    for (int i = 0; i < 8; i++) {
        int x = 20 + (i % 4) * 85;
        int y = 80 + (i / 4) * 100;
        rrect(x, y, 64, 64, 12, app_colors[i]);
    }

    // Dock with 4 apps
    rrect(20, 548, 320, 72, 18, 0x2A3358);
    static const uint32_t dock_colors[4] = { 0x2ECC71, 0x3498DB, 0xF39C12, 0xE74C3C };
    for (int i = 0; i < 4; i++)
        rrect(39 + i * 75, 556, 56, 56, 12, dock_colors[i]);

    // Home bar
    rrect(130, 626, 100, 6, 3, 0xFFFFFF);
}

// ---------------------------------------------------------------
// Start here
// ---------------------------------------------------------------
void kmain(void) {
    uart_puts("\n=====================\n");
    uart_puts("  Hello from my OS!\n");
    uart_puts("=====================\n");

    if (screen_init() < 0) {
        uart_puts("No screen found (ramfb missing).\n");
    } else {
        draw_home_screen();
        uart_puts("Screen ready: 360x640\n");
    }

    uart_puts("Type something and I'll echo it back.\n\n> ");
    for (;;) {
        char c = uart_getc();
        if (c == '\r') uart_puts("\n> ");
        else           uart_putc(c);
    }
}
