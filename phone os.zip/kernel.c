// Tiny phone OS, step 1: boot and talk over the serial port (UART).

#define UART_BASE  0x09000000UL            // PL011 UART on QEMU "virt"
#define UART_DR    (*(volatile unsigned int *)(UART_BASE + 0x00))
#define UART_FR    (*(volatile unsigned int *)(UART_BASE + 0x18))
#define UART_TXFF  (1 << 5)                // transmit FIFO full
#define UART_RXFE  (1 << 4)                // receive FIFO empty

static void uart_putc(char c) {
    while (UART_FR & UART_TXFF) { }
    UART_DR = c;
}

static void uart_puts(const char *s) {
    while (*s) {
        if (*s == '\n') uart_putc('\r');
        uart_putc(*s++);
    }
}

static char uart_getc(void) {
    while (UART_FR & UART_RXFE) { }
    return (char)UART_DR;
}

void kmain(void) {
    uart_puts("\n");
    uart_puts("=====================\n");
    uart_puts("  Hello from my OS!\n");
    uart_puts("=====================\n");
    uart_puts("Type something and I'll echo it back.\n");
    uart_puts("(Quit QEMU with Ctrl-A, then X)\n\n> ");

    for (;;) {
        char c = uart_getc();
        if (c == '\r') { uart_puts("\n> "); }
        else           { uart_putc(c); }
    }
}
